<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="admin/images/icon.jpg">
  <link rel="icon" type="image/png" href="admin/images/icon.jpg">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta property="og:url"           content="http://www.mrdeeps.rf.gd/" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="Dipesh Jamsutkar mrdeeps" />
  <meta property="og:description"   content="personal website" />
  <meta property="og:image"         content="http://www.mrdeeps/admin/images/icon.jpg" />
  <title>Dipesh Jamsudkar 
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
<!-- CSS Files -->
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/swiper.min.css">
<link rel="stylesheet" href="style.css">
<link href="admin/css/material-dashboard.css?v=6.1.6" rel="stylesheet" />
<!-- CSS Just for demo purpose, don't include it in your project -->
<link href="styles/main.css" rel="stylesheet" />
   <link href="admin/demo/demo.css" rel="stylesheet" />
  </head>
<body class="">
  <div class="wrapper">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="admin/images/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo"><a href="http://mrdeeps.rf.gd" class="simple-text logo-normal">
      Mrdeeps
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item  active">
            <a class="nav-link" href="admin/dashboard.php">
              <i class="material-icons"></i>
              <p>Login</p>
            </a>
          </li>
        <li class="nav-item  active">
        <a class="nav-link" href="index.php">
        <i class="material-icons"></i>
        <p>Home</p>
        </a>
        </li>
        
        </ul>
        </div>
        </div>
        
    
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <button class="navbar-toggler" style="color:black;"type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
         
        </div>
      </nav>
     
      <!-- End Navbar -->
      
      <div class="container">
      <div class="row">
      <div class="col-12">
      <div class="site-branding flex flex-column align-items-center">
      <h1 class="site-title"><a href="index.php" id="deeps" >Deeps</a></h1>
      <p class="site-description">Personal Website</p>
      </div><!-- .site-branding -->
      
      </div><!-- .col -->
      </div><!-- .row -->
      </div><!-- .container -->
      
      
      <div class="content">
        <div class="container-fluid">
          <div class="row">
          <?php 
          require'db.php';
          $sql = "SELECT *  FROM `tbl_image`";
          $res = mysqli_query ($con, $sql);
          while($row = mysqli_fetch_array($res)){
          $image = $row['image_name'];
          ?>
            <div class="col-md-12">
          <div class="col-md-4">
          <div class="card profile">
          <div class="card-avatar">
          <a href="images/<?php echo $image; ?>"> <br>
          <img id="img"  style="border-radius: 4%; height: 330px; width: 320px;  margin-left: 1px;margin-top: -16px; z-index: 9999; shadow: #f2f3f3;" src="images/<?php echo $row['image_name']; ?>" />
          </a>
          </div>
         <center>
          <p class="category" style="color: #262626;"><?php echo $row['image_description']; ?></p>
         </center>
          <div class="card-profile"> 
          <a href="download.php?file=<?php echo $image; ?>" class="btn btn-primary smooth-scroll mr-2"><i class="fa fa-download"></i></a> </div>
          </div>
          </div>
          </div>
          <?php
          }
          ?>
       
        
        </div></div></div>
     
     
     
     <!---footer start---->
     <footer class="sit-footer" >
     <div class="footer-bar" >
     <div class="outer-container">
     <div class="container-fluid">
     <div class="row justify-content-between">
     <div class="col-12 col-md-02">
     <div class="footer-copyright">
     
     <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script>  |  <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://instagram.com/_.mr_deeps_" target="_blank">Mrdeeps</a></p>
     
     </div><!-- .footer-copyright -->
     </div><!-- .col-xl-4 -->
     
     <div class="col-12 col-md-02">
     <div class="footer-social">
     <ul class="flex justify-content-center justify-content-md-end align-items-center">
     <li><a href="https://wa.me/919673961105?text=Hi"><i class="fa fa-whatsapp"></i></a></li>
     <li><a href="https://facebook.com/Mr.Deeps.9673"><i class="fa fa-facebook"></i></a></li>
     
     <li><a href="https://instagram.com/_.mr_deeps_"><i class="fa fa-instagram"></i></a></li>
     </ul>
     </div><!-- .footer-social -->
     </div><!-- .col-xl-4 -->
     </div><!-- .row -->
     </div><!-- .container-fluid -->
     </div><!-- .outer-container -->
     </div><!-- .footer-bar -->
     
  
  <!--   Core JS Files   -->
 
 <script type="text/javascript">
 
 var d = new Date();
 var t = d.getHours();
 if(t > 18)
 {
 document.body.style.backgroundColor = '#262625';
 document.getElementById("deeps").style.color =  "white";
 }else
 {
 document.body.style.backgroundColor = 'whitw';
 document.getElementById("deeps").style.color =  "#262625";
 }
 
 </script>
<script src="admin/js/core/jquery.min.js"></script>
<script src="admin/js/core/popper.min.js"></script>
<script src="admin/js/core/bootstrap-material-design.min.js"></script>
<script src="admin/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!-- Plugin for the momentJs  -->
<!-- Chartist JS -->
<!--  Notifications Plugin    -->
<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
<script src="admin/js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project! -->


   <script src="js/core/popper.min.js"></script>
   <script src="js/core/bootstrap.min.js"></script>
   <script src="js/now-ui-kit.js?v=2.1.2"></script>
   <script src="js/aos.js"></script>
   <script src="scripts/main.js"></script>
</body>

</html>