<?php

//database_connection.php

$connect = new PDO('mysql:host=sql205.epizy.com;dbname=epiz_25781411_mrdeeps', "epiz_25781411", "dipesh9673",);

?>
 