<?php 
include "../../db.php";

$id = 0;
if(isset($_POST['id'])){
   $id = mysqli_real_escape_string($con,$_POST['id']);
}

if($id > 0){

	// Check record exists
	$checkRecord = mysqli_query($con,"SELECT * FROM `ip` WHERE id=".$id);
	$totalrows = mysqli_num_rows($checkRecord);

	if($totalrows > 0){
		// Delete record
		$query = "DELETE FROM `ip` WHERE id=".$id;
		mysqli_query($con,$query);
	echo json_encode(array("statusCode"=>200));
		exit;
	}else{
        echo json_encode(array("statusCode"=>201));
        exit;
    }
}

echo 0;
exit;