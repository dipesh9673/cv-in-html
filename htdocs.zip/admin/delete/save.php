<?php
	include '../../db.php';
if(!empty($_FILES['file']['name'])) {
	/* rename the file name*/
move_uploaded_file($_FILES['file']['tmp_name'], '../../images/' . $_FILES['file']['name']);
 
	 
	$text=$_POST['text'];
	$date=$_POST['date'];
	$tag=$_POST['tag'];
	$link=$_POST['link'];
    $file = $_FILES['file']['name'];
    
	$sql = "INSERT INTO `posts`( `text`, `date`, `tag`, `link`, `file`) 
	VALUES ('$text','$date','$tag','$link', '$file')";
	
	if (mysqli_query($con, $sql)) {
	       	echo json_encode(array("statusCode"=>200));
    } else {
    echo json_encode(array("statusCode"=>201));
    } 
    }
 mysqli_close($con);
 
?>
 