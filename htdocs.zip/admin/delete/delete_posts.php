<?php 
include "../../db.php";
$id = 0;
if(isset($_POST['id'])){
   $id = mysqli_real_escape_string($con,$_POST['id']);
}

if($id > 0){

	// Check record exists
	$checkRecord = mysqli_query($con,"SELECT * FROM `posts` WHERE id=".$id);
	$totalrows = mysqli_num_rows($checkRecord);
    while ($r = mysqli_fetch_array($checkRecord)){ $unlink = $r['file']; }
    $path = "../images/";
    $r = "unlink($path$unlink)";
    
	if($totalrows > 0){
		// Delete record
		$query = "DELETE FROM `posts` WHERE id=".$id;
		mysqli_query($con,$query);
		
	echo json_encode(array("statusCode"=>200));
		exit;
	}else{
        echo json_encode(array("statusCode"=>201));
        exit;
    }
}
 unlink($unlink);

echo 0;
exit;