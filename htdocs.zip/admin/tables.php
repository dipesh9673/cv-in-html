<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../Images/Deeps.jpg">
  <link rel="icon" type="image/png" href="../Images/Deeps.jpg">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>Mrdeeps Admin panel
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link rel="stylesheet" href="../css/font-awesome.min.css">
  <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">  
  
  <link href="css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  
  <link href="demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="images/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo"><a href="http://mrdeeps.rf.gd" class="simple-text logo-normal">
      Mrdeeps
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item  ">
            <a class="nav-link" href="dashboard.php">
              <i class="material-icons"></i>
              <p>Dashboard</p>
            </a>
          </li>
     <li class="nav-item active" >
     <a class="nav-link active" href="dashboard.php">
     <i class="material-icons"></i>
     <p>Table List</p>
     </a>
     </li>
     
        </ul>
        </div>
        </div>
        
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a id="deeps" class="navbar-brand" href="javascript:;">Table List</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
         
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
                   
            
       
       <div class="card">
       <div class="card-header card-header-primary" id="ip">
       <h4 class="card-title" >Email</h4>
       <p class="card-category"> Contact </p>
       </div>
       <div class="card-body">
       <div class="table-responsive">
       <table class="table">
       <thead class=" text-primary">
       <th>
       NO
       </th>
       
       
       
       <th>
      Name
       </th>
       <th>
      Email
       </th>
       <th>
       Subject
       </th>
       <th>
       Message
       </th>
       <th>
       ACTION
       </th>
       
       </thead>
       <tbody>
     <?php
     require'../db.php';
     require'auth.php';
     $sqls = "SELECT * FROM `contact` ";  
    
     
     $results = mysqli_query($con,$sqls);
    
     while($rows = mysqli_fetch_array($results)){
     ?>
     <tr>
     <td>
     <?php echo $rows['id'];?>
     </td>
     <td>
     <?php echo $rows['userName'];?>
     </td>
     <td>
     <?php echo $rows['userEmail'];?>
     </td>
     <td class="text-primary">
     <?php echo $rows['subject'];?>
     </td>
     <td class="text-primary">
     <?php echo $rows['content'];?>
     </td>
     
     <td class="text-primary">
     
     <div  class="btn btn-primary btn-round" > <a class="deletes" data-id="<?php echo $rows['id'];?>">Delete</a> </div>
     </td>
     
     </tr>
     <?php
     }
     ?>
       </tbody>
       </table>
       </div>
       </div>
       </div>
      
        
       
       
      </div>
      <footer class="footer">
        <div class="container-fluid">
         <footer class="sit-footer"> 
         <div class="footer-bar">
         <div class="outer-container">
         <div class="container-fluid">
         <div class="row justify-content-between">
         <div class="col-12 col-md-6">
         <div class="footer-copyright">
         
         <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script>  |  <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://instagram.com/_.mr_deeps_" target="_blank">Mrdeeps</a></p>
         
         </div><!-- .footer-copyright -->
         </div><!-- .col-xl-4 -->
         
         <div class="col-12 col-md-6">
         <div class="footer-social">
         <ul class="flex justify-content-center justify-content-md-end align-items-center">
         <li><a href=""><i class="fa fa-whatsapp"></i></a></li>
         <li><a href="https://facebook.com/Mr.Deeps.9673"><i class="fa fa-facebook"></i></a></li>
         
         <li><a href="https://instagram.com/_.mr_deeps_"><i class="fa fa-instagram"></i></a></li>
         </ul>
         </div><!-- .footer-social -->
         </div><!-- .col-xl-4 -->
         </div><!-- .row -->
         </div><!-- .container-fluid -->
         </div><!-- .outer-container -->
         </div><!-- .footer-bar -->
         </footer><!-- .sit-footer -->
        </div>
      </footer>
    </div>
  </div>
  </div>
  </div>
   </div>

  <!--   Core JS Files   --> 
  <script>
  var d = new Date();
  var t = d.getHours();
  if(t > 18)
  {
  document.body.style.backgroundColor = '#262625';
  document.getElementById("deeps").style.color =  'white';
  }else
  {
  document.body.style.backgroundColor = 'whitw';
  document.getElementById("deeps").style.color =  '#262625';
  }
  </script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <script>
$(document).ready(function(){

    // Delete 
    $('.delete').click(function(){
        var el = this;

        // Delete id
        var id = $(this).data('id');
        
        var confirmalert = confirm("Are you sure?");
        if (confirmalert == true) {
            // AJAX Request
            $.ajax({
                url: 'delete/delete_ip.php',
                type: 'POST',
                data: { id:id },
              success: function(dataResult) {
              var dataResult = JSON.parse(dataResult);
              if(dataResult.statusCode==200){
                        // Remove row from HTML Table
                        $(el).closest('tr').css('background','#f2f3f3');
                        $(el).closest('tr').fadeOut(800,function(){
                            $(this).remove();
                        });
                    }else{
                        alert('Invalid ID.');
                    }
                }
            });
        }
    });
});
</script>
<script>
$(document).ready(function(){

    // Delete 
    $('.deletes').click(function(){
        var el = this;

        // Delete id
        var id = $(this).data('id');
        
        var confirmalert = confirm("Are you sure?");
        if (confirmalert == true) {
            // AJAX Request
            $.ajax({
                url: 'delete/delete_contact.php',
                type: 'POST',
                data: { id:id },
              success: function(dataResult) {
              var dataResult = JSON.parse(dataResult);
              if(dataResult.statusCode==200){
                        // Remove row from HTML Table
                        $(el).closest('tr').css('background','#f2f3f3');
                        $(el).closest('tr').fadeOut(800,function(){
                            $(this).remove();
                        });
                    }else{
                        alert('Invalid ID.');
                    }
                }
            });
        }
    });
});
</script>
<script>  
      $(document).ready(function(){  
           $.datepicker.setDefaults({  
                dateFormat: 'yy-mm-dd'   
           });  
           $(function(){  
                $("#from_date").datepicker();  
                $("#to_date").datepicker();  
           });  
           $('#filter').click(function(){  
                var from_date = $('#from_date').val();  
                var to_date = $('#to_date').val();  
                if(from_date != '' && to_date != '')  
                {  
                     $.ajax({  
                          url:"filter.php",  
                          method:"POST",  
                          data:{from_date:from_date, to_date:to_date},  
                          success:function(data)  
                          {  
                               $('#order_table').html(data);  
                          }  
                     });  
                }  
                else  
                {  
                     alert("Please Select Date");  
                }  
           });  
      });  
 </script>
  <script src="js/core/jquery.min.js"></script>
  <script src="js/core/popper.min.js"></script>
  <script src="js/core/bootstrap-material-design.min.js"></script>
  <script src="js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Plugin for the momentJs  -->
  <!-- Chartist JS -->
  <!--  Notifications Plugin    -->
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="js/demo/demo.js"></script>

</body>

</html>