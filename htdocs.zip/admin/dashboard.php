<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="images/icon.jpg">
  <link rel="icon" type="image/png" href="images/icon.jpg">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>Mrdeeps Admin panel
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link rel="stylesheet" href="../css/font-awesome.min.css">
  
  <link href="css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="images/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo"><a href="http://mrdeeps.rf.gd" class="simple-text logo-normal">
      Mrdeeps
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item  active">
            <a class="nav-link" href="dashboard.php">
              <i class="material-icons"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item  ">
            <a class="nav-link" href="tables.php">
              <i class="material-icons"></i>
              <p>Table List</p>
            </a>
          </li>
          <li class="nav-item  ">
          <a class="nav-link" href="logout.php">
          <i class="material-icons"></i>
          <p>Logout</p>
          </a>
          </li>
        </ul>
        </div>
        </div>
        
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a id="deeps" class="navbar-brand" href="javascript:;" >Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation" id="deeps">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
         
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
          <div class="col-md-4">
          <div class="card card-profile">
          <div class="card-avatar">
          <?php
          require'../db.php';
           require'auth.php';
          $name = htmlspecialchars($_SESSION["id"]);
         
          $sql = "SELECT * FROM users WHERE id='$name' ";
          $result = mysqli_query($con, $sql);
          while($row= mysqli_fetch_array($result)) { ?>
          <a href="images/<?php echo $row['profile'];?>">
          <img class="img"  src="images/<?php echo $row['profile']; ?>" />
          </a>
          </div>
          <div class="card-body">
          <h6 class="card-category text-gray"><?php echo $row['username'];?></h6>
          <h4 class="card-title"><?php echo $row['email']; }?></h4>
          <a href="https://instagram.com/_.mr_deeps_" class="btn btn-primary btn-round">Follow</a>
          </div>
          </div>
          </div>
          
          <div align="right">
         <input type="file" name="multiple_files" id="multiple_files" class=""  multiple />
          <span id="error_multiple_files"></span>
          </div>
          
          <div class="content">
          <div class="container-fluid">
          <div class="row">
          <div class="col-md-12">
          <div class="card">
          <div class="card-header card-header-primary">
          <h4 class="card-title ">POST</h4>
          <p class="card-category">Post Saved </p>
          </div>
          
          <div class="card-body">
          <div class="table-responsive" id="image_table">
          
          </div>
          </div>
          </div>
     </div>
     </div>
     </div></div></div></div></div></div>
      <div id="imageModal" class="modal fade" role="dialog"> <div class="modal-dialog"> <div class="modal-content"> <form method="POST" id="edit_image_form"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal">&times;</button> <h4 class="modal-title">Edit Image Details</h4> </div> <div class="modal-body"> <div class="form-group"> <label>Image Name</label> <input type="text" name="image_name" id="image_name" class="form-control" /> </div> <div class="form-group"> <label>Image Description</label> <input type="text" name="image_description" id="image_description" class="form-control" /> </div> </div> <div class="modal-footer"> <input type="hidden" name="image_id" id="image_id" value="" /> <input type="submit" name="submit" class="btn btn-info" value="Edit" /> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> </div> </form> </div> </div> </div>
      <footer class="footer">
        <div class="container-fluid">
         <footer class="sit-footer"> 
         <div class="footer-bar">
         <div class="outer-container">
         <div class="container-fluid">
         <div class="row justify-content-between">
         <div class="col-12 col-md-6">
         <div class="footer-copyright">
         
         <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script>  |  <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://instagram.com/_.mr_deeps_" target="_blank">Mrdeeps</a></p>
         
         </div><!-- .footer-copyright -->
         </div><!-- .col-xl-4 -->
         
         <div class="col-12 col-md-6">
         <div class="footer-social">
         <ul class="flex justify-content-center justify-content-md-end align-items-center">
         <li><a href=""><i class="fa fa-whatsapp"></i></a></li>
         <li><a href="https://facebook.com/Mr.Deeps.9673"><i class="fa fa-facebook"></i></a></li>
         
         <li><a href="https://instagram.com/_.mr_deeps_"><i class="fa fa-instagram"></i></a></li>
         </ul>
         </div><!-- .footer-social -->
         </div><!-- .col-xl-4 -->
         </div><!-- .row -->
         </div><!-- .container-fluid -->
         </div><!-- .outer-container -->
         </div><!-- .footer-bar -->
         </footer><!-- .sit-footer -->
        </div>
      </footer>
    </div>
  </div>

  <!--   Core JS Files   -->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <script>
 $(document).ready(function(){
 load_image_data();
 function load_image_data()
 {
 $.ajax({
 url:"fetch.php",
 method:"POST",
 success:function(data)
 {
 $('#image_table').html(data);
 }
 });
 } 
 $('#multiple_files').change(function(){
 var error_images = '';
 var form_data = new FormData();
 var files = $('#multiple_files')[0].files;
 if(files.length > 10)
 {
 error_images += 'You can not select more than 10 files';
 }
 else
 {
 for(var i=0; i<files.length; i++)
 {
 var name = document.getElementById("multiple_files").files[i].name;
 var ext = name.split('.').pop().toLowerCase();
 if(jQuery.inArray(ext, ['gif','png','jpg','jpeg']) == -1) 
 {
 error_images += '<p>Invalid '+i+' File</p>';
 }
 var oFReader = new FileReader();
 oFReader.readAsDataURL(document.getElementById("multiple_files").files[i]);
 var f = document.getElementById("multiple_files").files[i];
 var fsize = f.size||f.fileSize;
 if(fsize > 20000000)
 {
 error_images += '<p>' + i + ' File Size is very big</p>';
 }
 else
 {
 form_data.append("file[]", document.getElementById('multiple_files').files[i]);
 }
 }
 }
 if(error_images == '')
 {
 $.ajax({
 url:"upload.php",
 method:"POST",
 data: form_data,
 contentType: false,
 cache: false,
 processData: false,
 beforeSend:function(){
 $('#error_multiple_files').html('<img class="modal-dialog" src="images/LoaderIcon.gif"> </img>');
 },   
 success:function(data)
 {
 $('#error_multiple_files').html('<br /><label class="text-success">Uploaded</label>');
 load_image_data();
 }
 });
 }
 else
 {
 $('#multiple_files').val('');
 $('#error_multiple_files').html("<span class='text-danger'>"+error_images+"</span>");
 return false;
 }
 });  
 $(document).on('click', '.edit', function(){
 var image_id = $(this).attr("id");
 $.ajax({
 url:"edit.php",
 method:"post",
 data:{image_id:image_id},
 dataType:"json",
 success:function(data)
 {
 $('#imageModal').modal('show');
 $('#image_id').val(image_id);
 $('#image_name').val(data.image_name);
 $('#image_description').val(data.image_description);
 }
 });
 }); 
 $(document).on('click', '.delete', function(){
 var image_id = $(this).attr("id");
 var image_name = $(this).data("image_name");
 if(confirm("Are you sure you want to remove it?"))
 {
 $.ajax({
 url:"delete.php",
 method:"POST",
 data:{image_id:image_id, image_name:image_name},
 success:function(data)
 {
 load_image_data();
 alert("Image removed");
 }
 });
 }
 }); 
 $('#edit_image_form').on('submit', function(event){
 event.preventDefault();
 if($('#image_name').val() == '')
 {
 alert("Enter Image Name");
 }
 else
 {
 $.ajax({
 url:"update.php",
 method:"POST",
 data:$('#edit_image_form').serialize(),
 success:function(data)
 {
 $('#imageModal').modal('hide');
 load_image_data();
 alert('Image Details updated');
 }
 });
 }
 }); 
 });
 </script>
 <script>
 var d = new Date();
 var t = d.getHours();
 if(t > 18)
 {
 document.body.style.backgroundColor = '#262625';
 document.getElementById("deeps").style.color =  'white';
 }else
 {
 document.body.style.backgroundColor = 'whitw';
 document.getElementById("deeps").style.color =  '#262625';
 }
 </script>
  <script src="js/core/jquery.min.js"></script>
  <script src="js/core/popper.min.js"></script>
  <script src="js/core/bootstrap-material-design.min.js"></script>
  <script src="js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Plugin for the momentJs  -->
  <!-- Chartist JS -->
  <!--  Notifications Plugin    -->
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="js/demo/demo.js"></script>

</body>

</html>