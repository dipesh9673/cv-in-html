<?php
    require('../db.php');
    session_start();
    // If form submitted, insert values into the database.
    if (isset($_POST['username'])){
    
    $username = stripslashes($_REQUEST['username']); // removes backslashes
    $username = mysqli_real_escape_string($con,$username); //escapes special characters in a string
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($con,$password);
    
    //Checking is user existing in the database or not
    $query = "SELECT * FROM `users` WHERE username='$username' and password='".md5($password)."'";
    $result = mysqli_query($con,$query) or die(mysql_error());
while($ids = mysqli_fetch_array($result)) { $id = $ids['id'];}
    $rows = mysqli_num_rows($result);
    if($rows==1){
    $_SESSION['id'] = $id ;
    header("Location: dashboard.php"); // Redirect user to index.php
    }else{
    $msg = "<h3 style='color:white;'>Username/password is incorrect.</h3>";
    }
    }else{}
    ?>
  
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../Images/Deeps.jpg">
  <link rel="icon" type="image/png" href="../Images/Deeps.jpg">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>Mrdeeps Admin panel
  </title><meta property="og:url"           content="http://www.mrdeeps.rf.gd/" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="Dipesh Jansutkar mrdeeps" />
  <meta property="og:description"   content="personal website" />
  <meta property="og:image"         content="http://www.mrdeeps/admin/images/icon.jpg" />
  <meta content="width=device-width, initial-scale=1.0, shrink-to-fit=no" name="viewport" />
  
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link rel="stylesheet" href="../css/font-awesome.min.css">
  
  <link href="css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="images/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"
        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo"><a href="http://mrdeeps.rf.gd" class="simple-text logo-normal">
      Mrdeeps
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active">
            <a class="nav-link" href="login.php">
              <i class="material-icons"></i>
              <p>Login</p>
            </a>
          </li>
        
          <li class="nav-item  ">
            <a class="nav-link" href="../index.php">
              <i class="material-icons"></i>
              <p>Home</p>
            </a>
          </li>
        </ul>
        </div>
        </div>
        
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" id="deeps" href="javascript:;">Admin Area</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
         
        </div>
      </nav>
      <!-- End Navbar -->
        <div class="content">
        <div class="container-fluid">
        <div class="row">
        <div class="col-md-12">
        <div class="card">
        <div class="card-header card-header-primary">
        <h4 class="card-title "><b>LOGIN</h4>
        <p class="card-category"><?php echo $msg; ?></b> </p>
        </div>
        <div class="card-body">
        <div class="table-responsive">
        <center>
        <form action="login.php" method="POST" name="login" id="fm">
       <label>Username</label>
        <input class="input-field" type="text" placeholder="Username" name="username">
       <label>Password</label>
        <input class="input-field" type="password" placeholder="Password" name="password">
        <input type="submit" name="submit" class="btn" value="Login" >
        
        </form>
        <a href="sent.php"> Forgot password? </a>
        </center>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
      <footer class="footer">
        <div class="container-fluid">
         <footer class="sit-footer"> 
         <div class="footer-bar">
         <div class="outer-container">
         <div class="container-fluid">
         <div class="row justify-content-between">
         <div class="col-12 col-md-6">
         <div class="footer-copyright">
         
         <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script>  |  <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://instagram.com/_.mr_deeps_" target="_blank">Mrdeeps</a></p>
         
         </div><!-- .footer-copyright -->
         </div><!-- .col-xl-4 -->
         
         <div class="col-12 col-md-6">
         <div class="footer-social">
         <ul class="flex justify-content-center justify-content-md-end align-items-center">
         <li><a href=""><i class="fa fa-whatsapp"></i></a></li>
         <li><a href="https://facebook.com/Mr.Deeps.9673"><i class="fa fa-facebook"></i></a></li>
         
         <li><a href="https://instagram.com/_.mr_deeps_"><i class="fa fa-instagram"></i></a></li>
         </ul>
         </div><!-- .footer-social -->
         </div><!-- .col-xl-4 -->
         </div><!-- .row -->
         </div><!-- .container-fluid -->
         </div><!-- .outer-container -->
         </div><!-- .footer-bar -->
         </footer><!-- .sit-footer -->
        </div>
      </footer>
    </div>
  </div>

  <!--   Core JS Files   -->
  <script type="text/javascript">
  
  var d = new Date();
  var t = d.getHours();
  if(t > 18)
  {
  document.body.style.backgroundColor = '#262525';
  document.getElementById("fm").style.backgroundColor =  '#252525';
  
  document.getElementById("deeps").style.color =  'white';
  }else
  {
  document.body.style.backgroundColor = 'whitw';
  document.getElementById("deeps").style.color =  '#262625';
  }
  
  </script>
  <script src="js/core/jquery.min.js"></script>
  <script src="js/core/popper.min.js"></script>
  <script src="js/core/bootstrap-material-design.min.js"></script>
  <script src="js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Plugin for the momentJs  -->
  <!-- Chartist JS -->
  <!--  Notifications Plugin    -->
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="js/demo/demo.js"></script>

</body>

</html>