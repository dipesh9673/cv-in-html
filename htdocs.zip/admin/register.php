<?php
include_once("../db.php");
if(isset($_POST['btn-save'])) {
	$user_name = $_POST['username'];
	$user_email = $_POST['email'];
	$user_password = $_POST['password'];	
	$file = $_FILES['multiple_file']['name'];
	
	$sql = "SELECT email FROM users WHERE email='$user_email'";
	$resultset = mysqli_query($con, $sql) or die("database error:". mysqli_error($con));
	$row = mysqli_fetch_assoc($resultset);		
	if(!$row['email']){	
	move_uploaded_file($_FILES['multiple_file']['tmp_name'], 'images/' . $_FILES['multiple_file']['name']);
		$sql = "INSERT INTO users(`username`, `password`, `email`, `profile`) VALUES ('$user_name', '$user_password', '$user_email', '$file')";
		mysqli_query($con, $sql) or die("database error:". mysqli_error($con)."qqq".$sql);			
		echo "registered";
	} else {				
		echo "1";	 
	}
}
?>