
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../Images/Deeps.jpg">
  <link rel="icon" type="image/png" href="../Images/Deeps.jpg">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>Mrdeeps Admin panel
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link rel="stylesheet" href="../css/font-awesome.min.css">
  
  <link href="css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="images/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"
        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo"><a href="http://mrdeeps.rf.gd" class="simple-text logo-normal">
      Mrdeeps
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active">
            <a class="nav-link" href="login.php">
              <i class="material-icons"></i>
              <p>Login</p>
            </a>
          </li>
          <li class="nav-item ">
          <a class="nav-link" href="http://diwali2020.mrdeeps.rf.gd/create.php">
          <i class="material-icons"></i>
          <p>Diwali Wishes</p>
          </a>
          </li>
          
          <li class="nav-item  ">
            <a class="nav-link" href="../index.php">
              <i class="material-icons"></i>
              <p>Home</p>
            </a>
          </li>
        </ul>
        </div>
        </div>
        
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Admin Area</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
         
        </div>
      </nav>
      <!-- End Navbar -->
        <div class="content">
        <div class="container-fluid">
        <div class="row">
        <div class="col-md-12">
        <div class="card">
        <div class="card-header card-header-primary">
        <h4 class="card-title "><b>Change Password</h4>
        <p class="card-category" id="success"> <?php
        include('../db.php');
        if (isset($_GET["q"]) && isset($_GET["email"])) {
        $key = $_GET["q"];
        $email = $_GET["email"];
        $curDate = date("Y-m-d H:i:s");
        $query = mysqli_query($con,"
        SELECT * FROM `password_reset` WHERE `key`='".$key."' and `email`='".$email."';");
        $row = mysqli_num_rows($query);
        
        if ($row==""){
        $error .= '<h2>Invalid Link</h2>
        <p><a href="http://www.mrdeeps.rf.gd/admin/sent.php" style="color:white; font-weight:900;">Click here</a></p>';
        }else{
        $row = mysqli_fetch_assoc($query);
        $expDate = $row['expDate'];
        $keys = $row['key'];
        }
        }
      
        if(isset($_POST["submit"]) && ($expDate >= $curDate) && $key== $key ){
        if ($pass1!=$pass2){
        $error .= "<p>Password do not match, both password should be same.</p>";
        }else{
        $error="";
        $pass1 = mysqli_real_escape_string($con,$_POST["pass1"]);
        $pass2 = mysqli_real_escape_string($con,$_POST["pass2"]);
        $email = $_POST["email"];
        $curDate = date("Y-m-d H:i:s");
        $pass1 = md5($pass1);
        mysqli_query($con,
        "UPDATE `users` SET `password`='".$pass1."', `trn_date`='".$curDate."' WHERE `email`='".$email."';");	
        
        mysqli_query($con,"DELETE FROM `password_reset` WHERE `email`='".$email."';");		
        
        echo '<div class="error"><p>Congratulations! Your password has been updated successfully.</p>
        <p><a href="login.php" style="color:white; font-weight:900;">Click here</a> to Login.</p></div>';
        }		
        }else{
        echo  "<h2>Link Expired</h2>";
        }
        ?></p>
        </div>
        <div class="card-body">
        <div class="table-responsive">
        <center>
      
     <form method="post" action="" name="update">
     <input type="hidden" name="action" value="update" />
     
     <label><strong>Enter New Password:</strong></label><br />
     <input type="password" name="pass1" id="pass1" maxlength="15" required />
     <br />
     <label><strong>Re-Enter New Password:</strong></label><br />
     <input type="password" name="pass2" id="pass2" maxlength="15" required/>
     <br />
     <input type="hidden" name="email" value="<?php echo $email;?>"/>
     <input type="submit" id="reset" value="Reset Password" name="submit"/>
     </form>
     <?php

     ?>
     
     
        </center>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
      <footer class="footer">
        <div class="container-fluid">
         <footer class="sit-footer"> 
         <div class="footer-bar">
         <div class="outer-container">
         <div class="container-fluid">
         <div class="row justify-content-between">
         <div class="col-12 col-md-6">
         <div class="footer-copyright">
         
         <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script>  |  <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://instagram.com/_.mr_deeps_" target="_blank">Mrdeeps</a></p>
         
         </div><!-- .footer-copyright -->
         </div><!-- .col-xl-4 -->
         
         <div class="col-12 col-md-6">
         <div class="footer-social">
         <ul class="flex justify-content-center justify-content-md-end align-items-center">
         <li><a href=""><i class="fa fa-whatsapp"></i></a></li>
         <li><a href="https://facebook.com/Mr.Deeps.9673"><i class="fa fa-facebook"></i></a></li>
         
         <li><a href="https://instagram.com/_.mr_deeps_"><i class="fa fa-instagram"></i></a></li>
         </ul>
         </div><!-- .footer-social -->
         </div><!-- .col-xl-4 -->
         </div><!-- .row -->
         </div><!-- .container-fluid -->
         </div><!-- .outer-container -->
         </div><!-- .footer-bar -->
         </footer><!-- .sit-footer -->
        </div>
      </footer>
    </div>
  </div>

  <!--   Core JS Files   -->
  
  <script src="js/core/jquery.min.js"></script>
  <script src="js/core/popper.min.js"></script>
  <script src="js/core/bootstrap-material-design.min.js"></script>
  <script src="js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Plugin for the momentJs  -->
  <!-- Chartist JS -->
  <!--  Notifications Plugin    -->
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="js/demo/demo.js"></script>

</body>

</html>