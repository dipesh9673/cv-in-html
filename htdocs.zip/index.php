<?php
    require'ip.php';
    $age = (date('Y') - '1999');
?>
<!DOCTYPE html>
<html lang="en">
<head><meta name="google-site-verification" content="2RRG_igMZJoN7wd7BOTf_wW3HNDvFcrm-UmK9L7TOHA" />
  <meta charset="utf-8" />
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <link rel="icon" type="image/jpg" href="admin/images/icon.jpg">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta property="og:url"           content="http://www.mrdeeps.rf.gd/" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="Dipesh Jamsutkar mrdeeps" />
  <meta property="og:description"   content="personal website" />
  <meta property="og:image"         content="admin/images/icon.jpg" />
  <title>Dipesh Jamsudkar</title
  <!--Fonts and icons-->
  <link rel="canonical" href="http://wwww.mrdeeps.rf.gd/"> 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet">
<!-- CSS Files -->
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link rel="stylesheet" href="css/swiper.min.css">
  <link rel="stylesheet" href="style.css">
  <link href="admin/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
<!-- CSS Just for demo purpose, don't include it in your project -->
 <link href="styles/main.css" rel="stylesheet" />
 <link href="admin/demo/demo.css" rel="stylesheet" /><!-- Google Tag Manager -->
 <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
 new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
 j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
 'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
 })(window,document,'script','dataLayer','GTM-MP82VLG');</script>
 <!-- End Google Tag Manager -->
   <!-- Global site tag (gtag.js) - Google Analytics -->
 <script async src="https://www.googletagmanager.com/gtag/js?id=G-LSXQYCQ4W3"></script>
<script>
   window.dataLayer = window.dataLayer || [];
   function gtag(){dataLayer.push(arguments);}
   gtag('js', new Date());
   
   gtag('config', 'G-LSXQYCQ4W3');
</script>
</head>
<body >
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="admin/images/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo" ><a href="http://www.mrdeeps.rf.gd" class="simple-text logo-normal">
      Mrdeeps
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item  active">
            <a class="nav-link" href="admin/dashboard.php">
              <i class="material-icons"></i>
              <p>Login</p>
            </a>
          </li>
        <li class="nav-item  active">
        <a class="nav-link" href="gallary.php">
        <i class="material-icons"></i>
        <p>Gallary</p>
        </a>
        </li>
        
        </ul>
        </div>
        </div>
        
    
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <button class="navbar-toggler" style="color:black;"type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
         
        </div>
      </nav>
     
      <!-- End Navbar -->
      
      <div class="container">
      <div class="row">
      <div class="col-12">
      <div class="site-branding flex flex-column align-items-center">
      <h1 class="site-title" ><a href="index.php"  id="deeps">Deeps</a></h1>
      <p class="site-description">Personal Website</p>
      </div><!-- .site-branding -->
      
      </div><!-- .col -->
      </div><!-- .row -->
      </div><!-- .container -->
      
      <center>
      <div class="content" >
        <div class="container-fluid">
          <div class="row" id="cccc">
           
          <div class="col-md-6" >
          <div class="card profile">
          <div class="card-avatar">
          
          <a href="admin/images/D1.jpg"> <br>
          <img  style="border-radius: 4%; height: 380px; width: 300px;  margin-left:1px;margin-top: 6px; z-index: 9999;" src="admin/images/D1.jpg" type="image/jpg"/>
          </a>
          </div>
          <div class="card-body card-profile">
          <div class="h2 title">Dipesh Jamsudkar</div>
          <div class="card-profile"> 
          <p class="category ">ELECTRICIAN (NCVT), HSC(SCI).</p><a class="btn btn-primary smooth-scroll mr-2" href="#contact"  >Contact Me</a>
          <button  class="btn btn-primary smooth-scroll mr-2"  id="download" onClick="d()">Download CV</button>
          </div>
          </div>
          <div class="card-profile"> 
          <a href="https://wa.me/919673961105?text=Hi" class="btn btn-primary smooth-scroll mr-2"><i class="fa fa-whatsapp"></i></a> 
          </div>
          
          </div>
          </div>
        </div>
        </div>
        </div>
          </center>
          
         <div>
         <div class="container">
         <div class="card" data-aos="fade-up" data-aos-offset="10">
         <div class="row">
         <div class="col-lg-6 col-md-12">
         <div class="card-body">
         <div class="h4 mt-0 title">About</div>
         <p>Hello! I am Dipesh Jamsudkar. <br> Electrcian Student Ncvt Certified.</p>
         </div>
         </div>
         <div class="col-lg-6 col-md-5">
         <div class="card-body">
         <div class="h4 mt-0 title">Basic Information</div>
         <div class="row">
         <div class="col-sm-4"><strong class="text-uppercase">Age:</strong></div>
         <div class="col-sm-8"><?php echo $age; ?></div>
         </div>
         <div class="row mt-3">
         <div class="col-sm-4"><strong class="text-uppercase">Email:</strong></div>
         <div class="col-sm-8">dipesh9673@gmail.com</div>
         </div>
         <div class="row mt-3">
         <div class="col-sm-4"><strong class="text-uppercase">Phone:</strong></div>
         <div class="col-sm-8">+91 9673961105</div>
         </div>
         <div class="row mt-3">
         <div class="col-sm-4"><strong class="text-uppercase">Address:</strong></div>
         <div class="col-sm-8" onclick="dd()">315, PADVEKARWADI, DAPOLI,RATNAGIRI, MH, INDIA.</div>
         </div>
         <div class="row mt-3">
         <div class="col-sm-4"><strong class="text-uppercase">Language:</strong></div>
         <div class="col-sm-8">Marathi, Hindi, English.</div>
         </div>
         </div>
         </div>
         </div>
         </div>
         </div>
         </div>
         
         
         
        
         <div id="skill">
         <div class="container">
         <div class="h4 text-center mb-4 title" >Percentage </div>
         <div class="card" data-aos="fade-up" data-aos-anchor-placement="top-bottom">
         <div class="card-body">
         <div class="row">
         <div class="col-md-5">
         <div class="progress-container progress-primary"><span class="progress-badge">SSC</span>
         <div class="progress">
         <div class="progress-bar progress-bar-primary" data-aos="progress-full" data-aos-offset="10" data-aos-duration="2000" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 73.60%;"></div><span class="progress-value">73.60%</span>
         </div>
         </div>
         
         <div class="progress-container progress-primary"><span class="progress-badge">HSC</span>
         <div class="progress">
         <div class="progress-bar progress-bar-primary" data-aos="progress-full" data-aos-offset="10" data-aos-duration="2000" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 49%;"></div><span class="progress-value">49%</span>
         </div>
         </div>
         
         <div class="progress-container progress-primary"><span class="progress-badge">ITI</span>
         <div class="progress">
         <div class="progress-bar progress-bar-primary" data-aos="progress-full" data-aos-offset="10" data-aos-duration="2000" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 73.48%;"></div><span class="progress-value">73.48%</span>
         </div>
         </div>
         </div>
         </div>
         </div>
         </div>
         </div>
         </div>
       
         
         <div id="Education">
         <div class="container cc-experience">
         <div class="h4 text-center mb-4 title" id="deeps">Education </div>
         <div class="card">
         <div class="row">
         <div class="col-md-3 bg-primary" data-aos="fade-right" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body cc-experience-header">
         <p>2014-2015</p>
         <div class="h5">SSC</div>
         </div>
         </div>
         <div class="col-md-9" data-aos="fade-left" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body">
         <div class="h5">SSC</div>
         <p> From S.M.B. HIGH SCHOOL, GAONTALE.</p> 
         
         </div>
         </div>
         </div>
         </div>
         <div class="card">
         <div class="row">
         <div class="col-md-3 bg-primary" data-aos="fade-right" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body cc-experience-header">
         <p>August 2015 - July 2017</p>
         <div class="h5">Electrician (NCVT)</div>
         </div>
         </div>
         <div class="col-md-9" data-aos="fade-left" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body">
         <div class="h5">ELECTRICIAN</div>
         <p> FROM INDUSTRIAL TRAINING INSTITUTE, KHED.</p>
         </div>
         </div>
         </div>
         </div>
         <div class="card">
         <div class="row">
         <div class="col-md-3 bg-primary" data-aos="fade-right" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body cc-experience-header">
         <p>2018-  2020</p>
         <div class="h5">HSC (science)</div>
         </div>
         </div>
         <div class="col-md-9" data-aos="fade-left" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body">
         <div class="h5">HSC (science)</div>
         <p>FROM N.K.VARADKAR COLLEGE, DAPOLI.</p>
         </div>
         </div>
         </div>
         </div>
         </div>
         </div>
         
         <div id="e">
         <div class="container cc-education">
         <div class="h4 text-center mb-4 title" id="deeps">Education Qualifications</div>
         <div class="card">
         <div class="row">
         <div class="col-md-3 bg-primary" data-aos="fade-right" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body cc-education-header">
         <p>2018 - 2020</p>
         <div class="h5">COLLAGE</div>
         </div>
         </div>
         <div class="col-md-9" data-aos="fade-left" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body">
         <div class="h5">SCIENCE</div>
         <p class="category">SCHOOL OF HIGHER SECONDARY BOARD</p>
         
         </div>
         </div>
         </div>
         </div>
         <div class="card">
         <div class="row">
         <div class="col-md-3 bg-primary" data-aos="fade-right" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body cc-education-header">
         <p>2015 - 2017</p>
         <div class="h5">INDUSTRIAL TRAINING INSTITUTE</div>
         </div>
         </div>
         <div class="col-md-9" data-aos="fade-left" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body">
         <div class="h5">ELECTRICIAN </div>
         <p class="category">NATIONAL COUNCIL FOR VOCATIONAL TRAINING</p>
         </div>
         </div>
         </div>
         </div>
         <div class="card">
         <div class="row">
         <div class="col-md-3 bg-primary" data-aos="fade-right" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body cc-education-header">
         <p>2014 - 2015</p>
         <div class="h5">High School</div>
         </div>
         </div>
         <div class="col-md-9" data-aos="fade-left" data-aos-offset="50" data-aos-duration="500">
         <div class="card-body">
         <div class="h5">Mathematics</div>
         <p class="category">School of Secondary board</p>
         </div>
         </div>
         </div>
         </div>
         </div>
         </div>
         
         
         
         
         <div  id="contact">
         <div class="cc-contact-information" style="">
         <div class="container">
         <div class="cc-contact">
         <div class="row">
         <div class="col-md-11">
         <div class="card mb-0" data-aos="zoom-in">
         <div class="h4 text-center title" >Contact Me</div>
         <div class="card-body">
        <div id="frmContact">
        <div id="mail-status"></div>
        <div>
        <label style="padding-top:20px;">Name</label>
        <span id="userName-info" class="info"></span><br/>
        <input type="text" name="userName" id="userName" class="demoInputBox">
        </div>
        <div>
        <label>Email</label>
        <span id="userEmail-info" class="info"></span><br/>
        <input type="text" name="userEmail" id="userEmail" class="demoInputBox">
        </div>
        <div>
        <label>Subject</label> 
        <span id="subject-info" class="info"></span><br/>
        <input type="text" name="subject" id="subject" class="demoInputBox">
        </div>
        <div>
        <label>Content</label> 
        <span id="content-info" class="info"></span><br/>
        <textarea name="content" id="content" class="demoInputBox" rows="6"></textarea>
        </div>
        <div>
        <button name="submit" class="btnAction" onClick="sendContact();">Send</button>
        </div>
        </div>
        
         </div>
         
         <div class="col-md-05">
         <div class="card-body">
         <p class="mb-0"><strong>Address </strong></p>
         <p class="pb-2" onclick="dd()">315, PADVEKARWADI, DAPOLI,RATNAGIRI, MH, INDIA </p>
         <p class="mb-0"><strong>Phone</strong></p>
         <p class="pb-2">+919673961105</p>
         <p class="mb-0"><strong>Email</strong></p>
         <p>dipesh9673@gmail.com</p>
         </div>
         </div>
        
         </div>
         </div>
         </div>
         </div>
         </div>
         </div>
         </div> 
       <!-- Google Tag Manager (noscript) -->
       <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MP82VLG"
       height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
       <!-- End Google Tag Manager (noscript) -->
     <!---footer start---->
     <footer>
     <div class="footer-bar" >
     <div class="outer-container">
     <div class="container-fluid">
     <div class="row justify-content-between">
     <div class="col-12 col-md-02">
     <div class="footer-copyright">
     
     <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script>  |  <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://instagram.com/_.mr_deeps_" target="_blank">Mrdeeps</a></p>
     
     </div><!-- .footer-copyright -->
     </div><!-- .col-xl-4 -->
     
     <div class="col-12 col-md-02">
     <div class="footer-social">
     <ul class="flex justify-content-center justify-content-md-end align-items-center">
     <li><a href="https://wa.me/919673961105?text=Hi"><i class="fa fa-whatsapp"></i></a></li>
     <li><a href="https://facebook.com/Mr.Deeps.9673"><i class="fa fa-facebook"></i></a></li>
     
     <li><a href="https://instagram.com/_.mr_deeps_"><i class="fa fa-instagram"></i></a></li>
     </ul>
     </div><!-- .footer-social -->
     </div><!-- .col-xl-4 -->
     </div><!-- .row -->
     </div><!-- .container-fluid -->
     </div><!-- .outer-container -->
     </div><!-- .footer-bar -->
     </footer>
  <!--   Core JS Files   -->

<script type="text/javascript">

var d = new Date();
var t = d.getHours();
if(t > 18)
{
document.body.style.backgroundColor = '#262625';
document.getElementById("cccc").style.backgroundColor =  '#252525';
document.getElementById("deeps").style.color =  'white';
}else
{
document.body.style.backgroundColor = 'whitw';
  document.getElementById("deeps").style.color =  '#262625';
}

</script>
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
function sendContact() {
	var valid;	
	valid = validateContact();
	if(valid) {
		jQuery.ajax({
		url: "contact.php",
		data:'userName='+$("#userName").val()+'&userEmail='+$("#userEmail").val()+'&subject='+$("#subject").val()+'&content='+$(content).val(),
		type: "POST",
		success:function(data){
		$("#mail-status").html(data);
		},
		error:function (){}
		});
	}
}

function validateContact() {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
	
	if(!$("#userName").val()) {
		$("#userName-info").html("(required)");
		$("#userName").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#userEmail").val()) {
		$("#userEmail-info").html("(required)");
		$("#userEmail").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#userEmail").val().match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/)) {
		$("#userEmail-info").html("(invalid)");
		$("#userEmail").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#subject").val()) {
		$("#subject-info").html("(required)");
		$("#subject").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#content").val()) {
		$("#content-info").html("(required)");
		$("#content").css('background-color','#FFFFDF');
		valid = false;
	}
	
	return valid;
}
</script>
<script type="text/javascript">
function d ()
 {
window.open('Dipesh_Jamsudkar_resume.pdf');
}
 
 function dd () {
 window.open('https://maps.google.com/?q=17.701863,73.259305');
 }
</script>
<script src="js/now-ui-kit.js?v=2.1.2"></script>
<script src="js/aos.js"></script>
<script src="scripts/main.js"></script>
<script src="admin/js/core/jquery.min.js"></script>
<script src="admin/js/core/popper.min.js"></script>
<script src="admin/js/core/bootstrap-material-design.min.js"></script>
<script src="admin/js/plugins/perfect-scrollbar.jquery.min.js"></script>
<!-- Plugin for the momentJs  -->
<!-- Chartist JS -->
<!--  Notifications Plugin    -->
<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
<script src="admin/js/material-dashboard.js?v=2.1.2" type="text/javascript"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project! -->

</body>

</html>