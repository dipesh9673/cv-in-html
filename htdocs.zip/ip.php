<?php

if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
    {
      $ipaddress = $_SERVER['HTTP_CLIENT_IP']."\r\n";
    }
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check if ip is pass from proxy
    {
      $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR']."\r\n";
    }
else
    {
      $ipaddress = $_SERVER['REMOTE_ADDR']."\r\n";
    }
$b= $_SERVER['HTTP_USER_AGENT']."\r\n";
	require('db.php');
	date_default_timezone_set('Asia/Kolkata');
	$trn_date = date("Y-m-d H:i:s");
	
	$query = "INSERT into `ip` (ip, browser, trn_date) VALUES ('$ipaddress','$b',  '$trn_date')";
	$result = mysqli_query($con,$query);
	if($result){
	echo '';
	}else{
	echo '';
	}
?>