<?php
require'db.php';
$to = "dipesh9673@gmail.com";
$subject = $_POST["subject"];
$m = $_POST["content"];
$Headers = "From: " . $_POST["userName"] . "<". $_POST["userEmail"] .">\r\n";
$m = wordwrap($msg,70);
if(mail($to, $subject, $m, $Headers)) {
$sql = "INSERT INTO `contact`(userName, userEmail, subject, content) VALUES ('".$_POST['userName']."','".$_POST['userEmail']."','".$_POST['subject']."','".$_POST['content']."')"; 
mysqli_query($con, $sql);
print "<p id='success'>Contact Mail Sent.</p>";
} else {
print "<p id='error'>Problem in Sending Mail.</p>";
}
?>